<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card">
                <div class="card-header">
                    <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.otherExpense.title_singular')); ?>

                </div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route("frontend.other-expenses.update", [$otherExpense->id])); ?>" enctype="multipart/form-data">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label class="required" for="expense_id"><?php echo e(trans('cruds.otherExpense.fields.expense')); ?></label>
                            <select class="form-control select2" name="expense_id" id="expense_id" required>
                                <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" <?php echo e((old('expense_id') ? old('expense_id') : $otherExpense->expense->id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('expense')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('expense')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.otherExpense.fields.expense_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="amount"><?php echo e(trans('cruds.otherExpense.fields.amount')); ?></label>
                            <input class="form-control" type="number" name="amount" id="amount" value="<?php echo e(old('amount', $otherExpense->amount)); ?>" step="0.01" required>
                            <?php if($errors->has('amount')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('amount')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.otherExpense.fields.amount_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="date_spent"><?php echo e(trans('cruds.otherExpense.fields.date_spent')); ?></label>
                            <input class="form-control date" type="text" name="date_spent" id="date_spent" value="<?php echo e(old('date_spent', $otherExpense->date_spent)); ?>" required>
                            <?php if($errors->has('date_spent')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('date_spent')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.otherExpense.fields.date_spent_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label for="description"><?php echo e(trans('cruds.otherExpense.fields.description')); ?></label>
                            <textarea class="form-control" name="description" id="description"><?php echo e(old('description', $otherExpense->description)); ?></textarea>
                            <?php if($errors->has('description')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('description')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.otherExpense.fields.description_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <input  type="hidden" name="user_id" id="user_id" value="<?php echo e(Auth::user()->id); ?>">
                        </div>
                        <div class="form-group">
                            <button class="btn btn-danger" type="submit">
                                <?php echo e(trans('global.save')); ?>

                            </button>
                            <a class="btn btn-default" href="<?php echo e(route('frontend.other-expenses.index')); ?>">
                                <?php echo e(trans('global.cancel')); ?>

                            </a>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/developer/Desktop/laravelApps/Stano/v3/tms/resources/views/frontend/otherExpenses/edit.blade.php ENDPATH**/ ?>