<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('fleet_data_create')): ?>
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route('admin.fleet-datas.create')); ?>">
                <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.fleetData.title_singular')); ?>

            </a>
            <button class="btn btn-warning" data-toggle="modal" data-target="#csvImportModal">
                <?php echo e(trans('global.app_csvImport')); ?>

            </button>
            <?php echo $__env->make('csvImport.modal', ['model' => 'FleetData', 'route' => 'admin.fleet-datas.parseCsvImport'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.fleetData.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <table class=" table table-bordered table-striped table-hover ajaxTable datatable datatable-FleetData">
            <thead>
                <tr>
                    <th width="10">

                    </th>
                    <th>
                        <?php echo e(trans('cruds.fleetData.fields.order_number')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.fleetData.fields.journey_date')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.fleetData.fields.vehicle_reg_no')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.fleetData.fields.destination')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.fleetData.fields.customer_name')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.fleetData.fields.invoice_number')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.fleetData.fields.quantity')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.fleetData.fields.amount_paid_in')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.fleetData.fields.amount_paid_out')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.fleetData.fields.profit_loss')); ?>

                    </th>
                    <th>
                        <?php echo e(trans('cruds.fleetData.fields.user')); ?>

                    </th>
                    <th>
                        &nbsp;
                    </th>
                </tr>
            </thead>
        </table>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('fleet_data_delete')): ?>
  let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>';
  let deleteButton = {
    text: deleteButtonTrans,
    url: "<?php echo e(route('admin.fleet-datas.massDestroy')); ?>",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).data(), function (entry) {
          return entry.id
      });

      if (ids.length === 0) {
        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

        return
      }

      if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
<?php endif; ?>

  let dtOverrideGlobals = {
    buttons: dtButtons,
    processing: true,
    serverSide: true,
    retrieve: true,
    aaSorting: [],
    ajax: "<?php echo e(route('admin.fleet-datas.index')); ?>",
    columns: [
      { data: 'placeholder', name: 'placeholder' },
{ data: 'order_number', name: 'order_number' },
{ data: 'journey_date', name: 'journey_date' },
{ data: 'vehicle_reg_no', name: 'vehicle_reg_no' },
{ data: 'destination', name: 'destination' },
{ data: 'customer_name', name: 'customer_name' },
{ data: 'invoice_number', name: 'invoice_number' },
{ data: 'quantity', name: 'quantity' },
{ data: 'amount_paid_in', name: 'amount_paid_in' },
{ data: 'amount_paid_out', name: 'amount_paid_out' },
{ data: 'profit_loss', name: 'profit_loss' },
{ data: 'user_name', name: 'user.name' },
{ data: 'actions', name: '<?php echo e(trans('global.actions')); ?>' }
    ],
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  };
  let table = $('.datatable-FleetData').DataTable(dtOverrideGlobals);
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/developer/Desktop/laravelApps/Stano/v3/tms/resources/views/admin/fleetDatas/index.blade.php ENDPATH**/ ?>