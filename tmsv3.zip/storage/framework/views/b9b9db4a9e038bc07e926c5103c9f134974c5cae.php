<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card">
                <div class="card-header">
                    <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.fleetData.title')); ?>

                </div>

                <div class="card-body">
                    <div class="form-group">
                        <div class="form-group">
                            <a class="btn btn-default" href="<?php echo e(route('frontend.fleet-datas.index')); ?>">
                                <?php echo e(trans('global.back_to_list')); ?>

                            </a>
                        </div>
                        <table class="table table-bordered table-striped">
                            <tbody>
                                <tr>
                                    <th>
                                        <?php echo e(trans('cruds.fleetData.fields.order_number')); ?>

                                    </th>
                                    <td>
                                        <?php echo e($fleetData->order_number); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        <?php echo e(trans('cruds.fleetData.fields.journey_date')); ?>

                                    </th>
                                    <td>
                                        <?php echo e($fleetData->journey_date); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        <?php echo e(trans('cruds.fleetData.fields.vehicle_reg_no')); ?>

                                    </th>
                                    <td>
                                        <?php echo e($fleetData->vehicle_reg_no); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        <?php echo e(trans('cruds.fleetData.fields.destination')); ?>

                                    </th>
                                    <td>
                                        <?php echo e($fleetData->destination); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        <?php echo e(trans('cruds.fleetData.fields.customer_name')); ?>

                                    </th>
                                    <td>
                                        <?php echo e($fleetData->customer_name); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        <?php echo e(trans('cruds.fleetData.fields.invoice_number')); ?>

                                    </th>
                                    <td>
                                        <?php echo e($fleetData->invoice_number); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        <?php echo e(trans('cruds.fleetData.fields.quantity')); ?>

                                    </th>
                                    <td>
                                        <?php echo e($fleetData->quantity); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        <?php echo e(trans('cruds.fleetData.fields.amount_paid_in')); ?>

                                    </th>
                                    <td>
                                        <?php echo e($fleetData->amount_paid_in); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        <?php echo e(trans('cruds.fleetData.fields.amount_paid_out')); ?>

                                    </th>
                                    <td>
                                        <?php echo e($fleetData->amount_paid_out); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        <?php echo e(trans('cruds.fleetData.fields.profit_loss')); ?>

                                    </th>
                                    <td>
                                        <?php echo e($fleetData->profit_loss); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        <?php echo e(trans('cruds.fleetData.fields.user')); ?>

                                    </th>
                                    <td>
                                        <?php echo e($fleetData->user->name ?? ''); ?>

                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="form-group">
                            <a class="btn btn-default" href="<?php echo e(route('frontend.fleet-datas.index')); ?>">
                                <?php echo e(trans('global.back_to_list')); ?>

                            </a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/developer/Desktop/laravelApps/Stano/v3/tms/resources/views/frontend/fleetDatas/show.blade.php ENDPATH**/ ?>