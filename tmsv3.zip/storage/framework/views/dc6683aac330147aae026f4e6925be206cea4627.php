<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card">
                <div class="card-header">
                    <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.otherExpense.title')); ?>

                </div>

                <div class="card-body">
                    <div class="form-group">
                        <div class="form-group">
                            <a class="btn btn-default" href="<?php echo e(route('frontend.other-expenses.index')); ?>">
                                <?php echo e(trans('global.back_to_list')); ?>

                            </a>
                        </div>
                        <table class="table table-bordered table-striped">
                            <tbody>
                                <tr>
                                    <th>
                                        <?php echo e(trans('cruds.otherExpense.fields.id')); ?>

                                    </th>
                                    <td>
                                        <?php echo e($otherExpense->id); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        <?php echo e(trans('cruds.otherExpense.fields.expense')); ?>

                                    </th>
                                    <td>
                                        <?php echo e($otherExpense->expense->name ?? ''); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        <?php echo e(trans('cruds.otherExpense.fields.amount')); ?>

                                    </th>
                                    <td>
                                        <?php echo e($otherExpense->amount); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        <?php echo e(trans('cruds.otherExpense.fields.date_spent')); ?>

                                    </th>
                                    <td>
                                        <?php echo e($otherExpense->date_spent); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        <?php echo e(trans('cruds.otherExpense.fields.description')); ?>

                                    </th>
                                    <td>
                                        <?php echo e($otherExpense->description); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        <?php echo e(trans('cruds.otherExpense.fields.user')); ?>

                                    </th>
                                    <td>
                                        <?php echo e($otherExpense->user->name ?? ''); ?>

                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="form-group">
                            <a class="btn btn-default" href="<?php echo e(route('frontend.other-expenses.index')); ?>">
                                <?php echo e(trans('global.back_to_list')); ?>

                            </a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/developer/Desktop/laravelApps/Stano/v3/tms/resources/views/frontend/otherExpenses/show.blade.php ENDPATH**/ ?>