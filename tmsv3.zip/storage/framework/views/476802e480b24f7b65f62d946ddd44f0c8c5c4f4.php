<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        Expenses Report
    </div>

    <div class="card-body">
        <form action="<?php echo e(route('admin.reports.postexpenses')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="From">Date From</label>
                        <input class="form-control date" type="text" name="date_from" id="date_from" required>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="To">Date To</label>
                        <input class="form-control date" type="text" name="date_to" id="date_to" required>
                    </div>
                </div>
                <div class="col-lg 4">
                    <input style="margin-top: 30px" type="submit" id="filter" value="Search" class="btn btn-success ml-4">                           
                </div>
            </div>
        </form>
  
        <hr>
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-OtherExpense">
                <thead>
                    <tr>
                        <th>&nbsp;</th>
                      
                        <th>
                            <?php echo e(trans('cruds.otherExpense.fields.expense')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.otherExpense.fields.amount')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.otherExpense.fields.date_spent')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.otherExpense.fields.description')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.otherExpense.fields.user')); ?>

                        </th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $otherExpenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $otherExpense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($otherExpense->id); ?>">
                            <td>&nbsp;</td>
                          
                            <td>
                                <?php echo e($otherExpense->expense->name ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($otherExpense->amount ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($otherExpense->date_spent ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($otherExpense->description ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($otherExpense->user->name ?? ''); ?>

                            </td>
                            

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        
                    </tr>
                    <tr> 
                        <td>&nbsp;</td>
                        <td>  <strong> Total Expenses</strong> </td>
                       
                        
                        
                       <td> <strong>
                            <?php
                            $sum = 0;                          
                            foreach($otherExpenses as $key => $otherExpense){
                                $sum += $otherExpense->amount;
                            }
                            echo number_format($sum, 2);
         
                            ?>
                        </strong></td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                      
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-OtherExpense:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/developer/Desktop/laravelApps/Stano/v3/tms/resources/views/admin/reports/expenses.blade.php ENDPATH**/ ?>