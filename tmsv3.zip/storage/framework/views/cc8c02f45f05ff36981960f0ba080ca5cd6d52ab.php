<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.report.title')); ?>

    </div>

    <div class="card-body">
        <p>
            Text coming soon...
        </p>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/developer/Desktop/laravelApps/Stano/v3/tms/resources/views/admin/reports/index.blade.php ENDPATH**/ ?>