<aside class="main-sidebar sidebar-dark-primary elevation-4" style="min-height: 917px;">
    <!-- Brand Logo -->
    <a href="#" class="brand-link">
        <span class="brand-text font-weight-light"><?php echo e(trans('panel.site_title')); ?></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user (optional) -->

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route("admin.home")); ?>">
                        <i class="fas fa-fw fa-tachometer-alt nav-icon">
                        </i>
                        <p>
                            <?php echo e(trans('global.dashboard')); ?>

                        </p>
                    </a>
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('fleet_data_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.fleet-datas.index")); ?>" class="nav-link <?php echo e(request()->is("admin/fleet-datas") || request()->is("admin/fleet-datas/*") ? "active" : ""); ?>">
                            <i class="fa-fw nav-icon fas fa-cogs">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.fleetData.title')); ?>

                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('money_received_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.money-receiveds.index")); ?>" class="nav-link <?php echo e(request()->is("admin/money-receiveds") || request()->is("admin/money-receiveds/*") ? "active" : ""); ?>">
                            <i class="fa-fw nav-icon fas fa-cogs">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.moneyReceived.title')); ?>

                            </p>
                        </a>
                    </li>
                <?php endif; ?>
              
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('report_access')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->is("admin/reports*") ? "menu-open" : ""); ?>">
                        <a class="nav-link nav-dropdown-toggle" href="#">
                            <i class="fa-fw nav-icon fas fa-users">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.report.title')); ?>

                                <i class="right fa fa-fw fa-angle-left nav-icon"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.reports.floats")); ?>" class="nav-link <?php echo e(request()->is("admin/reports/floats") || request()->is("admin/reports/floats/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-unlock-alt">

                                        </i>
                                        <p>
                                            Float Report
                                        </p>
                                    </a>
                                </li>
                            
                            
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.reports.orders")); ?>" class="nav-link <?php echo e(request()->is("admin/reports/orders") || request()->is("admin/reports/orders/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-briefcase">

                                        </i>
                                        <p>
                                            Orders Report
                                        </p>
                                    </a>
                                </li>
                            
                            
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.reports.expenses")); ?>" class="nav-link <?php echo e(request()->is("admin/reports/expenses") || request()->is("admin/reports/expenses/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-user">

                                        </i>
                                        <p>
                                            Other Expenses Report
                                        </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.reports.profitloss")); ?>" class="nav-link <?php echo e(request()->is("admin/reports/profitloss") || request()->is("admin/reports/profitloss/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-user">

                                        </i>
                                        <p>
                                            Profit/Loss Report
                                        </p>
                                    </a>
                                </li>
                        </ul>
                    </li>
                <?php endif; ?>
                <!------------------------------end Reports-------------------------------- -->
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management_access')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->is("admin/permissions*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/roles*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/users*") ? "menu-open" : ""); ?>">
                        <a class="nav-link nav-dropdown-toggle" href="#">
                            <i class="fa-fw nav-icon fas fa-users">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.userManagement.title')); ?>

                                <i class="right fa fa-fw fa-angle-left nav-icon"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.permissions.index")); ?>" class="nav-link <?php echo e(request()->is("admin/permissions") || request()->is("admin/permissions/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-unlock-alt">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.permission.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.roles.index")); ?>" class="nav-link <?php echo e(request()->is("admin/roles") || request()->is("admin/roles/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-briefcase">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.role.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.users.index")); ?>" class="nav-link <?php echo e(request()->is("admin/users") || request()->is("admin/users/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-user">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.user.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('float_management_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.float-managements.index")); ?>" class="nav-link <?php echo e(request()->is("admin/float-managements") || request()->is("admin/float-managements/*") ? "active" : ""); ?>">
                            <i class="fa-fw nav-icon fas fa-cogs">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.floatManagement.title')); ?>

                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('send_float_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.send-floats.index")); ?>" class="nav-link <?php echo e(request()->is("admin/send-floats") || request()->is("admin/send-floats/*") ? "active" : ""); ?>">
                            <i class="fa-fw nav-icon fas fa-cogs">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.sendFloat.title')); ?>

                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expense_category_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.expense-categories.index")); ?>" class="nav-link <?php echo e(request()->is("admin/expense-categories") || request()->is("admin/expense-categories/*") ? "active" : ""); ?>">
                            <i class="fa-fw nav-icon fas fa-cogs">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.expenseCategory.title')); ?>

                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('other_expense_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.other-expenses.index")); ?>" class="nav-link <?php echo e(request()->is("admin/other-expenses") || request()->is("admin/other-expenses/*") ? "active" : ""); ?>">
                            <i class="fa-fw nav-icon fas fa-cogs">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.otherExpense.title')); ?>

                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(file_exists(app_path('Http/Controllers/Auth/ChangePasswordController.php'))): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profile_password_edit')): ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->is('profile/password') || request()->is('profile/password/*') ? 'active' : ''); ?>" href="<?php echo e(route('profile.password.edit')); ?>">
                                <i class="fa-fw fas fa-key nav-icon">
                                </i>
                                <p>
                                    <?php echo e(trans('global.change_password')); ?>

                                </p>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
                <li class="nav-item">
                    <a href="#" class="nav-link" onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                        <p>
                            <i class="fas fa-fw fa-sign-out-alt nav-icon">

                            </i>
                            <p><?php echo e(trans('global.logout')); ?></p>
                        </p>
                    </a>
                </li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside><?php /**PATH /home/developer/Desktop/laravelApps/Stano/v3/tms/resources/views/partials/menu.blade.php ENDPATH**/ ?>