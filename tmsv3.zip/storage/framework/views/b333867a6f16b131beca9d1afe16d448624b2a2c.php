<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.floatManagement.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.float-managements.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="transaction_type"><?php echo e(trans('cruds.floatManagement.fields.transaction_type')); ?></label>
                <input class="form-control <?php echo e($errors->has('transaction_type') ? 'is-invalid' : ''); ?>" type="text" name="transaction_type" id="transaction_type" value="<?php echo e(old('transaction_type', '')); ?>" required>
                <?php if($errors->has('transaction_type')): ?>
                    <span class="text-danger"><?php echo e($errors->first('transaction_type')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.floatManagement.fields.transaction_type_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="transactio_ref"><?php echo e(trans('cruds.floatManagement.fields.transactio_ref')); ?></label>
                <input class="form-control <?php echo e($errors->has('transactio_ref') ? 'is-invalid' : ''); ?>" type="text" name="transactio_ref" id="transactio_ref" value="<?php echo e(old('transactio_ref', '')); ?>">
                <?php if($errors->has('transactio_ref')): ?>
                    <span class="text-danger"><?php echo e($errors->first('transactio_ref')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.floatManagement.fields.transactio_ref_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="amount"><?php echo e(trans('cruds.floatManagement.fields.amount')); ?></label>
                <input class="form-control <?php echo e($errors->has('amount') ? 'is-invalid' : ''); ?>" type="number" name="amount" id="amount" value="<?php echo e(old('amount', '')); ?>" step="0.01" required>
                <?php if($errors->has('amount')): ?>
                    <span class="text-danger"><?php echo e($errors->first('amount')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.floatManagement.fields.amount_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="user_id"><?php echo e(trans('cruds.floatManagement.fields.user')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('user') ? 'is-invalid' : ''); ?>" name="user_id" id="user_id" required>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('user_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('user')): ?>
                    <span class="text-danger"><?php echo e($errors->first('user')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.floatManagement.fields.user_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/developer/Desktop/laravelApps/Stano/v3/tms/resources/views/admin/floatManagements/create.blade.php ENDPATH**/ ?>