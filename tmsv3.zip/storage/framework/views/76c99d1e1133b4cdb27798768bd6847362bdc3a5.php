<?php $__env->startSection('content'); ?>


<div class="card">
    <div class="card-header">
        Float Report
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-floatReport">
                <thead>
                    <tr>
                        <th>
                           User
                        </th>
                        <th>
                            Role
                         </th>
                        <th>
                            Float Balance
                        </th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $floats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $float): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="test1">
                            <td>
                                <?php echo e($float->user ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($float->Role ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($float->running_balance ?? ''); ?>

                            </td>
                     
                        </tr>
                       
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr> 
                        <td>  <strong> Total Float Balance</strong> </td>
                        <td>&nbsp;</td>
                        <td> <strong>
                            <?php
                            $sum = 0;                          
                            foreach($floats as $key => $float){
                                $sum += $float->running_balance;
                            }
                            echo number_format($sum, 2);
         
                            ?>
                        </strong></td>
                    
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>


<script>
$(function () {
let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
$.extend(true, $.fn.dataTable.defaults, {
orderCellsTop: true,
order: [[ 1, 'desc' ]],
pageLength: 100,
});
let table = $('.datatable-floatReport:not(.ajaxTable)').DataTable({ buttons: dtButtons })
$('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
  $($.fn.dataTable.tables(true)).DataTable()
      .columns.adjust();
});

})

</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/developer/Desktop/laravelApps/Stano/v3/tms/resources/views/admin/reports/floats.blade.php ENDPATH**/ ?>