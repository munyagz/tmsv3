<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.fleetData.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.fleet-datas.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="order_number"><?php echo e(trans('cruds.fleetData.fields.order_number')); ?></label>
                <input class="form-control <?php echo e($errors->has('order_number') ? 'is-invalid' : ''); ?>" type="text" name="order_number" id="order_number" value="<?php echo e(old('order_number', '')); ?>" required>
                <?php if($errors->has('order_number')): ?>
                    <span class="text-danger"><?php echo e($errors->first('order_number')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.fleetData.fields.order_number_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="journey_date"><?php echo e(trans('cruds.fleetData.fields.journey_date')); ?></label>
                <input class="form-control date <?php echo e($errors->has('journey_date') ? 'is-invalid' : ''); ?>" type="text" name="journey_date" id="journey_date" value="<?php echo e(old('journey_date')); ?>" required>
                <?php if($errors->has('journey_date')): ?>
                    <span class="text-danger"><?php echo e($errors->first('journey_date')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.fleetData.fields.journey_date_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="vehicle_reg_no"><?php echo e(trans('cruds.fleetData.fields.vehicle_reg_no')); ?></label>
                <input class="form-control <?php echo e($errors->has('vehicle_reg_no') ? 'is-invalid' : ''); ?>" type="text" name="vehicle_reg_no" id="vehicle_reg_no" value="<?php echo e(old('vehicle_reg_no', '')); ?>" required>
                <?php if($errors->has('vehicle_reg_no')): ?>
                    <span class="text-danger"><?php echo e($errors->first('vehicle_reg_no')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.fleetData.fields.vehicle_reg_no_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="destination"><?php echo e(trans('cruds.fleetData.fields.destination')); ?></label>
                <input class="form-control <?php echo e($errors->has('destination') ? 'is-invalid' : ''); ?>" type="text" name="destination" id="destination" value="<?php echo e(old('destination', '')); ?>" required>
                <?php if($errors->has('destination')): ?>
                    <span class="text-danger"><?php echo e($errors->first('destination')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.fleetData.fields.destination_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="customer_name"><?php echo e(trans('cruds.fleetData.fields.customer_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('customer_name') ? 'is-invalid' : ''); ?>" type="text" name="customer_name" id="customer_name" value="<?php echo e(old('customer_name', '')); ?>" required>
                <?php if($errors->has('customer_name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('customer_name')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.fleetData.fields.customer_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="invoice_number"><?php echo e(trans('cruds.fleetData.fields.invoice_number')); ?></label>
                <input class="form-control <?php echo e($errors->has('invoice_number') ? 'is-invalid' : ''); ?>" type="text" name="invoice_number" id="invoice_number" value="<?php echo e(old('invoice_number', '')); ?>" required>
                <?php if($errors->has('invoice_number')): ?>
                    <span class="text-danger"><?php echo e($errors->first('invoice_number')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.fleetData.fields.invoice_number_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="quantity"><?php echo e(trans('cruds.fleetData.fields.quantity')); ?></label>
                <input class="form-control <?php echo e($errors->has('quantity') ? 'is-invalid' : ''); ?>" type="text" name="quantity" id="quantity" value="<?php echo e(old('quantity', '')); ?>" required>
                <?php if($errors->has('quantity')): ?>
                    <span class="text-danger"><?php echo e($errors->first('quantity')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.fleetData.fields.quantity_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="amount_paid_out"><?php echo e(trans('cruds.fleetData.fields.amount_paid_out')); ?></label>
                <input class="form-control <?php echo e($errors->has('amount_paid_out') ? 'is-invalid' : ''); ?>" type="number" name="amount_paid_out" id="amount_paid_out" value="<?php echo e(old('amount_paid_out', '')); ?>" step="0.01" required>
                <?php if($errors->has('amount_paid_out')): ?>
                    <span class="text-danger"><?php echo e($errors->first('amount_paid_out')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.fleetData.fields.amount_paid_out_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/developer/Desktop/laravelApps/Stano/v3/tms/resources/views/admin/fleetDatas/create.blade.php ENDPATH**/ ?>