<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card">
                <div class="card-header">
                    <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.sendFloat.title_singular')); ?>

                </div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route("frontend.send-floats.store")); ?>" enctype="multipart/form-data">
                        <?php echo method_field('POST'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label class="required" for="date_sent"><?php echo e(trans('cruds.sendFloat.fields.date_sent')); ?></label>
                            <input class="form-control date" type="text" name="date_sent" id="date_sent" value="<?php echo e(old('date_sent')); ?>" required>
                            <?php if($errors->has('date_sent')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('date_sent')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.sendFloat.fields.date_sent_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="amount"><?php echo e(trans('cruds.sendFloat.fields.amount')); ?></label>
                            <input class="form-control" type="number" name="amount" id="amount" value="<?php echo e(old('amount', '')); ?>" step="0.01" required>
                            <?php if($errors->has('amount')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('amount')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.sendFloat.fields.amount_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="transaction_ref"><?php echo e(trans('cruds.sendFloat.fields.transaction_ref')); ?></label>
                            <input class="form-control" type="text" name="transaction_ref" id="transaction_ref" value="<?php echo e(old('transaction_ref', '')); ?>" required>
                            <?php if($errors->has('transaction_ref')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('transaction_ref')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.sendFloat.fields.transaction_ref_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="sent_to_id"><?php echo e(trans('cruds.sendFloat.fields.sent_to')); ?></label>
                            <select class="form-control select2" name="sent_to_id" id="sent_to_id" required>
                                <?php $__currentLoopData = $sent_tos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>" <?php echo e(old('sent_to_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('sent_to')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('sent_to')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.sendFloat.fields.sent_to_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <input  type="hidden" name="sent_by_id" id="sent_by_id" value="<?php echo e(Auth::user()->id); ?>">
                        </div>
                        <div class="form-group">
                            <button class="btn btn-danger" type="submit">
                                <?php echo e(trans('global.save')); ?>

                            </button>
                            <a class="btn btn-default" href="<?php echo e(route('frontend.send-floats.index')); ?>">
                                <?php echo e(trans('global.cancel')); ?>

                            </a>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/developer/Desktop/laravelApps/Stano/v3/tms/resources/views/frontend/sendFloats/create.blade.php ENDPATH**/ ?>