<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card">
                <div class="card-header">
                    <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.moneyReceived.title_singular')); ?>

                </div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route("frontend.money-receiveds.store")); ?>" enctype="multipart/form-data">
                        <?php echo method_field('POST'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label class="required" for="date_received"><?php echo e(trans('cruds.moneyReceived.fields.date_received')); ?></label>
                            <input class="form-control date" type="text" name="date_received" id="date_received" value="<?php echo e(old('date_received')); ?>" required>
                            <?php if($errors->has('date_received')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('date_received')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.moneyReceived.fields.date_received_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="amount"><?php echo e(trans('cruds.moneyReceived.fields.amount')); ?></label>
                            <input class="form-control" type="number" name="amount" id="amount" value="<?php echo e(old('amount', '')); ?>" step="0.01" required>
                            <?php if($errors->has('amount')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('amount')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.moneyReceived.fields.amount_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label for="transaction_ref"><?php echo e(trans('cruds.moneyReceived.fields.transaction_ref')); ?></label>
                            <input class="form-control" type="text" name="transaction_ref" id="transaction_ref" value="<?php echo e(old('transaction_ref', '')); ?>">
                            <?php if($errors->has('transaction_ref')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('transaction_ref')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.moneyReceived.fields.transaction_ref_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <input  type="hidden" name="user_id" id="user_id" value="<?php echo e(Auth::user()->id); ?>">
                        </div>
                        <div class="form-group">
                            <button class="btn btn-danger" type="submit">
                                <?php echo e(trans('global.save')); ?>

                            </button>
                            <a class="btn btn-default" href="<?php echo e(route('frontend.money-receiveds.index')); ?>">
                                <?php echo e(trans('global.cancel')); ?>

                            </a>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/developer/Desktop/laravelApps/Stano/v3/tms/resources/views/frontend/moneyReceiveds/create.blade.php ENDPATH**/ ?>