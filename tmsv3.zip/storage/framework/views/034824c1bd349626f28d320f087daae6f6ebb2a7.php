<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card">
                <div class="card-header">
                    <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.fleetData.title_singular')); ?>

                </div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route("frontend.fleet-datas.update", [$fleetData->id])); ?>" enctype="multipart/form-data">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label class="required" for="order_number"><?php echo e(trans('cruds.fleetData.fields.order_number')); ?></label>
                            <input class="form-control" type="text" name="order_number" id="order_number" value="<?php echo e(old('order_number', $fleetData->order_number)); ?>" required>
                            <?php if($errors->has('order_number')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('order_number')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.fleetData.fields.order_number_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="journey_date"><?php echo e(trans('cruds.fleetData.fields.journey_date')); ?></label>
                            <input class="form-control date" type="text" name="journey_date" id="journey_date" value="<?php echo e(old('journey_date', $fleetData->journey_date)); ?>" required>
                            <?php if($errors->has('journey_date')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('journey_date')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.fleetData.fields.journey_date_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="vehicle_reg_no"><?php echo e(trans('cruds.fleetData.fields.vehicle_reg_no')); ?></label>
                            <input class="form-control" type="text" name="vehicle_reg_no" id="vehicle_reg_no" value="<?php echo e(old('vehicle_reg_no', $fleetData->vehicle_reg_no)); ?>" required>
                            <?php if($errors->has('vehicle_reg_no')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('vehicle_reg_no')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.fleetData.fields.vehicle_reg_no_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="destination"><?php echo e(trans('cruds.fleetData.fields.destination')); ?></label>
                            <input class="form-control" type="text" name="destination" id="destination" value="<?php echo e(old('destination', $fleetData->destination)); ?>" required>
                            <?php if($errors->has('destination')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('destination')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.fleetData.fields.destination_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="customer_name"><?php echo e(trans('cruds.fleetData.fields.customer_name')); ?></label>
                            <input class="form-control" type="text" name="customer_name" id="customer_name" value="<?php echo e(old('customer_name', $fleetData->customer_name)); ?>" required>
                            <?php if($errors->has('customer_name')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('customer_name')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.fleetData.fields.customer_name_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="invoice_number"><?php echo e(trans('cruds.fleetData.fields.invoice_number')); ?></label>
                            <input class="form-control" type="text" name="invoice_number" id="invoice_number" value="<?php echo e(old('invoice_number', $fleetData->invoice_number)); ?>" required>
                            <?php if($errors->has('invoice_number')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('invoice_number')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.fleetData.fields.invoice_number_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="quantity"><?php echo e(trans('cruds.fleetData.fields.quantity')); ?></label>
                            <input class="form-control" type="text" name="quantity" id="quantity" value="<?php echo e(old('quantity', $fleetData->quantity)); ?>" required>
                            <?php if($errors->has('quantity')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('quantity')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.fleetData.fields.quantity_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label for="amount_paid_in"><?php echo e(trans('cruds.fleetData.fields.amount_paid_in')); ?></label>
                            <input class="form-control" type="number" name="amount_paid_in" id="amount_paid_in" value="<?php echo e(old('amount_paid_in', $fleetData->amount_paid_in)); ?>" step="0.01">
                            <?php if($errors->has('amount_paid_in')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('amount_paid_in')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.fleetData.fields.amount_paid_in_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="amount_paid_out"><?php echo e(trans('cruds.fleetData.fields.amount_paid_out')); ?></label>
                            <input class="form-control" type="number" name="amount_paid_out" id="amount_paid_out" value="<?php echo e(old('amount_paid_out', $fleetData->amount_paid_out)); ?>" step="0.01" required>
                            <?php if($errors->has('amount_paid_out')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('amount_paid_out')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.fleetData.fields.amount_paid_out_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-danger" type="submit">
                                <?php echo e(trans('global.save')); ?>

                            </button>
                            <a class="btn btn-default" href="<?php echo e(route('frontend.fleet-datas.index')); ?>">
                                <?php echo e(trans('global.cancel')); ?>

                            </a>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/developer/Desktop/laravelApps/Stano/v3/tms/resources/views/frontend/fleetDatas/edit.blade.php ENDPATH**/ ?>