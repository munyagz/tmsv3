<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.floatManagement.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.float-managements.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.floatManagement.fields.transaction_type')); ?>

                        </th>
                        <td>
                            <?php echo e($floatManagement->transaction_type); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.floatManagement.fields.transactio_ref')); ?>

                        </th>
                        <td>
                            <?php echo e($floatManagement->transactio_ref); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.floatManagement.fields.amount')); ?>

                        </th>
                        <td>
                            <?php echo e($floatManagement->amount); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.floatManagement.fields.running_balance')); ?>

                        </th>
                        <td>
                            <?php echo e($floatManagement->running_balance); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.floatManagement.fields.user')); ?>

                        </th>
                        <td>
                            <?php echo e($floatManagement->user->name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.floatManagement.fields.created_at')); ?>

                        </th>
                        <td>
                            <?php echo e($floatManagement->created_at); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.float-managements.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/developer/Desktop/laravelApps/Stano/v3/tms/resources/views/admin/floatManagements/show.blade.php ENDPATH**/ ?>