<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
       Profit/loss report
    </div>

    <div class="card-body">
        <form action="<?php echo e(route('admin.reports.postprofitloss')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="From">Date From</label>
                        <input class="form-control date" type="text" name="date_from" id="date_from" required>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="To">Date To</label>
                        <input class="form-control date" type="text" name="date_to" id="date_to" required>
                    </div>
                </div>
                <div class="col-lg 4">
                    <input style="margin-top: 30px" type="submit" id="filter" value="Search" class="btn btn-success ml-4">                           
                </div>
            </div>
        </form>
  
        <hr>
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-profitLoss">
                <thead>
                    <tr>
                        <th>&nbsp;</th>
                        <th>
                           Date
                        </th>
                        <th>
                            Description
                        </th>
                        <th>
                            Type
                        </th>
                        <th>
                            Amount Paid In
                        </th>
                        <th>
                            Amount Paid Out
                        </th>
                        <th>
                            Margin
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $Profitlosses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $profitLoss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="Pl3456">
                            <td>&nbsp;</td>
                            <td>
                                <?php echo e($profitLoss->Date ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($profitLoss->Description ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($profitLoss->Type ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($profitLoss->amount_paid_in ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($profitLoss->amount_paid_out ?? ''); ?>


                            </td>
                            <td>
                                <?php echo e($profitLoss->Margin ?? ''); ?>


                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr> 
                        <td>&nbsp;</td>
                        <td>  <strong> Totals </strong> </td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        
                        <td> <strong>
                            <?php
                            $sum = 0;                          
                            foreach($Profitlosses as $key => $profitLoss){
                                $sum += $profitLoss->amount_paid_in;
                            }
                            echo number_format($sum, 2);
         
                            ?>
                        </strong></td>
                        <td> <strong>
                            <?php
                            $sum = 0;                          
                            foreach($Profitlosses as $key => $profitLoss){
                                $sum += $profitLoss->amount_paid_out;
                            }
                            echo number_format($sum, 2);
         
                            ?>
                        </strong></td>
                        <td> <strong>
                            <?php
                            $sum = 0;                          
                            foreach($Profitlosses as $key => $profitLoss){
                                $sum += $profitLoss->Margin;
                            }
                            echo number_format($sum, 2);
         
                            ?>
                        </strong></td>
                       
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##

<script>
    $(function () {
 let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-profitLoss:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/developer/Desktop/laravelApps/Stano/v3/tms/resources/views/admin/reports/profitloss.blade.php ENDPATH**/ ?>